package com.cts.bean;
public class RegisterBean 
	{
	       private String First_Name;
	       private String Last_Name;
	       private String Age;
	       private String MobileNumber;
	       private String username;
	       private String password;
	       private String password1;
	       private String userType;
	       
	       
	       
	       public String getPassword() {
	              return password;
	       }
	       public void setPassword(String password) {
	              this.password = password;
	       }
	       public String getUserType() {
	              return userType;
	       }
	       public void setUserType(String userType) {
	              this.userType = userType;
	       }
	       public String getFirst_Name() 
	       {
	              return First_Name;
	       }
	       public void setFirst_Name(String First_Name) 
	       {
	              this.First_Name = First_Name;
	       }
	       
	       
	       public String getLast_Name() 
	       {
	              return Last_Name;
	       }
	       public void setLast_Name(String Last_Name) 
	       {
	              this.Last_Name = Last_Name;
	       }
	       
	       
	       
	       public String getMobileNumber() 
	       {
	              return MobileNumber;
	       }
	       public void setMobileNumber(String MobileNumber) 
	       {
	              this.MobileNumber =MobileNumber;
	       }
	       
	       
	       public String getAge() 
	       {
	              return Age;
	       }
	       public void setAge(String Age) 
	       {
	              this.Age =Age;
	       }
	       
	       
	       public void setUserName(String username)
	       {
	              this.username =username;
	       }
	       public String getUserName() {
	              return username;
	       }
	       
	       public String getpassword() 
	       {
	              return password;
	       }
	       public void setpassword(String password) 
	       {
	              this.password =password;
	       }
	       
	       public void setPassword1(String password1)
	       {
	              this.password1 = password1;
	       }
	       public String getPassword1() {
	              return password1 ;
	       }
	       
	       
	}



