package com.cts.service;

import java.util.List; 

import com.cts.bean.UploadBean;


public interface UploadService {
	public int addUpload(UploadBean upload);
	
	
	
}